//
//  IlnessSearchViewController.swift
//  Medicina
//
//  Created by Masha on 24/12/2018.
//  Copyright © 2018 Masha. All rights reserved.
//

import UIKit

// Контроллер болезни, на который мы добавили тэйбл вью
class IlnessSearchViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    // все возможные лекарства
    var allIllnesses: [String]? {
        guard let allKeys = DataBase.shared.data?.keys else {
            return nil
        }
        return Array(allKeys)
    }
    
    // те, которые показываем в данный момент
    var illnessesToShow: [String]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.illnessesToShow = allIllnesses
    }


    /// UITableViewDataSource Поставляет данные для таблицы с поиском болезней
    
    /// Конфигурирует ячейку для таблицы
    ///
    /// - Parameters:
    ///   - tableView: таблица, для которой мы запрашиваем ячейку
    ///   - indexPath: индекс, для которого мы запрашиваем ячейку
    /// - Returns: ячефка
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // получаем ячейку по идентификатору, который задали на сториборде в паспорте у ячейки
        let cell = tableView.dequeueReusableCell(withIdentifier: "ilnessCellReuseId", for: indexPath)
        
        //заполняем ячейку
        cell.textLabel?.text = illnessesToShow?[indexPath.row]
        
        return cell
    }
    
    // количество ячеек в таблице
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return illnessesToShow?.count ?? 0
    }
    
    
    
    //UITableViewDelegate
    
    // Сообщает, что пользователь нажал на ячейку по адресу indexPath
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let myStoryboard = UIStoryboard.init(name: "MyStoryboard", bundle: nil)
        let questionVC = myStoryboard.instantiateViewController(withIdentifier: "QuestionVC") as! QuestionViewController
        guard let selectedVariant = illnessesToShow?[indexPath.row] else {
            return
        }
        
        questionVC.title = selectedVariant
        questionVC.currentQuestion = DataBase.shared.data?[selectedVariant]
        show(questionVC, sender: nil)
    }

}

extension IlnessSearchViewController: UISearchBarDelegate {
// UISearchBarDelegate

/// Сёрчбар говорит нам, что текст изменился
///
/// - Parameters:
///   - searchBar: сёрчбар, который нам это говорит
///   - searchText: текст, который сейчас введён
func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
    // фильтруем массив названий, оставляем только подходящие
    // подходящие - это те, которые начинаются с searchText
    illnessesToShow = allIllnesses?.filter({ (pillName) -> Bool in
        pillName.hasPrefix(searchText)
    })
    
    // обновляем таблицу с новыми данными
    tableView.reloadData()
    }
}
