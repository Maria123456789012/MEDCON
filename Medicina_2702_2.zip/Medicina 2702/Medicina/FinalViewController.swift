//
//  FinalViewController.swift
//  Medicina
//
//  Created by Masha on 10/02/2019.
//  Copyright © 2019 Masha. All rights reserved.
//

import UIKit

class FinalViewController: UIViewController {

    @IBOutlet weak var finalLabel: UILabel!
    
    @IBOutlet weak var finalTxt: UITextView!
    
    public var finalText: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        finalTxt.text = finalText
      
    }
    



}
