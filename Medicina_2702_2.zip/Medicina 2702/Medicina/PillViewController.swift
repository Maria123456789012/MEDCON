//
//  PillViewController.swift
//  Medicina
//
//  Created by Masha on 20/01/2019.
//  Copyright © 2019 Masha. All rights reserved.
//

import UIKit

class PillViewController: UITableViewController, UISearchBarDelegate {
    
    var allIllnesses: [String]? {
        guard let allKeys = DataBase.shared.data?.keys else {
            return nil
        }
        return Array(allKeys)
    }
    
    var illnessesToShow: [String]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        illnessesToShow = allIllnesses
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Pillcell", for: indexPath)
        
        cell.textLabel?.text = illnessesToShow?[indexPath.row]
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return illnessesToShow?.count ?? 0
    }
    
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let myStoryboard = UIStoryboard.init(name: "MyStoryboard", bundle: nil)
        let pillVC = myStoryboard.instantiateViewController(withIdentifier: "PilldiscriptionVC")
        pillVC.title = illnessesToShow?[indexPath.row]
        show(pillVC, sender: nil)
        
        let cell = tableView.cellForRow(at: indexPath)
        if cell?.textLabel?.text == "Chai"
        {
            pillVC.view.backgroundColor = .green
        }
    }
    
   // UISearchBarDelegate
    
    /// Сёрчбар говорит нам, что текст изменился
    ///
    /// - Parameters:
    ///   - searchBar: сёрчбар, который нам это говорит
    ///   - searchText: текст, который сейчас введён
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        // фильтруем массив названий, оставляем только подходящие
        // подходящие - это те, которые начинаются с searchText
        illnessesToShow = allIllnesses?.filter({ (pillName) -> Bool in
            pillName.hasPrefix(searchText)
        })
        
        // обновляем таблицу с новыми данными
        tableView.reloadData()
    }

}
