//
//  NetworkService.swift
//  Medicina
//
//  Created by Masha on 27/02/2019.
//  Copyright © 2019 Masha. All rights reserved.
//

import Foundation


public struct NetworkError: Error {
    
    var description: String
}


class NetworkService {
    
    public typealias Ilnesses = [String: Question]
    
    // Пока что берём зашитые на устройстве данные
    public func loadIlnesses(completion: @escaping (Ilnesses?, Error?) -> Void) {
        let bundle = Bundle.main
        let filePathj = bundle.path(forResource: "mock", ofType: "json")
        guard let filePath = filePathj else {
            return
        }
        let fileUrl = URL(fileURLWithPath: filePath)
        let data = try? Data(contentsOf: fileUrl)
        if let jsonData = try? JSONSerialization.jsonObject(with: data!, options: [.allowFragments]) {
            
            DataBase.shared.data = self.parse(jsonData)
            
            completion(DataBase.shared.data, NetworkError(description: "Ошибка сервера, данные не пришли"))
        }
//        guard let url = URL(string: "https://medcon-98054.firebaseio.com/medcon-98054.json") else {
//            completion(nil, NetworkError(description: "Не получилось создать URL из строки"))
//            return
//        }
//
//        let downloadIllnessesTask = URLSession.shared.dataTask(with: url) { (data, response, error) in
//            guard let downloadedData = data else {
//                let bundle = Bundle(for: type(of: self))
//                let filePathj = bundle.path(forResource: "test", ofType: "json")
//                guard let filePath = filePathj else {
//                    return
//                }
//                let fileUrl = URL(fileURLWithPath: filePath)
//                let data = try? Data(contentsOf: fileUrl)
//                if let jsonData = try? JSONSerialization.jsonObject(with: data!, options: [.allowFragments]) {
//
//                    DataBase.shared.data = self.parse(jsonData)
//
//                    completion(DataBase.shared.data, NetworkError(description: "Ошибка сервера, данные не пришли"))
//                }
//
//                return
//            }
//
//            guard let json = try? JSONSerialization.jsonObject(with: downloadedData, options: []) else {
//                return
//            }
//
//            let illnesses = self.parse(json)
//            completion(illnesses, nil)
//
//        }
//
//        downloadIllnessesTask.resume()
    }
    
//    func getMockData -> Ilnesses? {
//
//    }
//
    
    public func parse(_ json: Any) -> Ilnesses? {
        guard let json = json as? [String: Any] else {
            return nil
        }
        
        guard let keywords = json["Ключевые слова"]  as? [String: Any] else {
            return nil
        }
        
        var roots = [String: Question]()
        for (keyword, question) in keywords {
            
            if let question = question as? [String : Any],
                let tree = question["Вопрос"] as? [String : Any] {
                roots[keyword] = self.parseQuestion(questionDictionary: tree)
            }
        }
        
        return roots
    }
    
    func parseQuestion(questionDictionary: [String: Any]) -> Question? {
        guard let questionText = questionDictionary["Текст"] as? String else {
            return nil
        }
        
        var answers = [Answer]()
        if let answersDictionary = questionDictionary["Ответы"] as? [String: Any] {
            for (_, answerDictionary) in answersDictionary {
                guard let answerDictionary = answerDictionary as? [String: Any] else {
                    return nil
                }
                
                let answer = Answer(text: answerDictionary["Текст"] as! String)
                
                if let final = answerDictionary["Финал"] as? String {
                    answer.final = final
                }
                
                if let nextQuestionDict = answerDictionary["Вопрос"] as? [String : Any] {
                    answer.nextQuestion = self.parseQuestion(questionDictionary: nextQuestionDict)
                }
                
                answers.append(answer)
            }
        }
        
        let question = Question(text: questionText, answers: answers)
        
        return question
    }
    
}
