//
//  DataBase.swift
//  Medicina
//
//  Created by Masha on 10/02/2019.
//  Copyright © 2019 Masha. All rights reserved.
//


class DataBase {
    static let shared = DataBase()
    
    var data: [String: Question]?
//    var data: [String: Question] {
//        let daBolit = Answer(text: "Da")
//        let neBolit = Answer(text: "Net")
//        daBolit.final = "Popei chau"
//        neBolit.final = "Vse ravno popei cahu"
//        let gorloBolitQuestion = Question(text: "Горло болит?", answers: [daBolit, neBolit])
//        let daZalozhen = Answer(text: "Da")
//        let neZalozhen = Answer(text: "Net")
//        let neSilnoZalozhen = Answer(text: "Ne silno")
//        daZalozhen.nextQuestion = gorloBolitQuestion
//        neZalozhen.final = "Ne kapai v nos"
//        neSilnoZalozhen.final = "Vismorkausya"
//        let noseZalozhenQuestion = Question(text: "Нос заложен?", answers: [daZalozhen, neZalozhen, neSilnoZalozhen])
//        let noAnswer = Answer(text: "Net")
//        let yesAnswer = Answer(text: "Da")
//        noAnswer.final = "Togda ne otit"
//        yesAnswer.nextQuestion = noseZalozhenQuestion
//
//        let firstOtitQuestion = Question(text: "Болят уши?", answers: [yesAnswer, noAnswer])
//        let otit = ["Otit": firstOtitQuestion]
//
//        return otit
//    }
}
