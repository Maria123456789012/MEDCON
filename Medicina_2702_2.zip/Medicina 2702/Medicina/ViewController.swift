//
//  ViewController.swift
//  Medicina
//
//  Created by Masha on 05.12.18.
//  Copyright © 2018 Masha. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var myImageView = UIImageView()
    let titulImage = UIImage(named: "Titul")
    
    var mylabel = UILabel()
    var button = UIButton()
    var click = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myImageView = UIImageView(image: titulImage)
        myImageView.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height / 2)
        myImageView.contentMode = .scaleToFill
        view.addSubview(myImageView)

        mylabel.frame = CGRect(x: 0, y: 0, width: self.view.bounds.width, height: 26)
        mylabel.center = view.center
        mylabel.text = "MEDCON"
        mylabel.numberOfLines = 0
        mylabel.font = UIFont.systemFont(ofSize: 25, weight: .bold)
        mylabel.textAlignment = .center
        mylabel.backgroundColor = .white
        mylabel.textColor = UIColor.black
        view.addSubview(mylabel)
        
        button.frame = CGRect(x: 0, y: 0, width: self.view.bounds.width, height: 100)
        button.center = view.center
        button.center.y = view.center.y + 100
        button.addTarget(self, action: #selector(download), for: UIControlEvents.touchUpInside)
        button.backgroundColor = .blue
        button.setTitle("Запуск приложения", for: .normal)
        view.addSubview(button)
    }
    
    //    label.frame = CGRect(x: 0, y: 0, width: 250, height: 100)
    //     label.center = view.center
    //     label.backgroundColor = .red
    //     label.text = " "
    //     label.textColor = .white
    //     label.numberOfLines = 0
    //     view.addSubview(label)
    
 
    
    @objc
    func buttonTapped() {
        // получаем сториборд, на котором наши контоллеры
        let myStoryboard = UIStoryboard.init(name: "MyStoryboard", bundle: nil)
        // получаем нужный нам контроллер по имени (которое задаётся в паспорте)
        let searchVC = myStoryboard.instantiateViewController(withIdentifier: " navigationRoot")
        // показываем его
        present(searchVC, animated: true, completion: nil)
    }
    
    @objc
    func download() {
        let ns = NetworkService()
        ns.loadIlnesses(completion: { (ilnesses, error) in
            self.buttonTapped()
        })
    }
    
}
