//
//  Answer.swift
//  Medicina
//
//  Created by Masha on 10/02/2019.
//  Copyright © 2019 Masha. All rights reserved.
//


class Answer  {
    
    let text: String
    var nextQuestion: Question?
    var final: String?
    
    init(text: String) {
        self.text = text
    }

}
