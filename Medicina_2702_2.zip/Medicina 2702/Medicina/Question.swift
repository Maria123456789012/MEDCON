//
//  Question.swift
//  Medicina
//
//  Created by Masha on 10/02/2019.
//  Copyright © 2019 Masha. All rights reserved.
//


class Question {
    
    let text: String
    var answers: [Answer]
    
    init(text: String, answers: [Answer]) {
        self.text = text
        self.answers = answers
    }

}
