//
//  QuestionViewController.swift
//  Medicina
//
//  Created by Masha on 10/02/2019.
//  Copyright © 2019 Masha. All rights reserved.
//

import UIKit

class QuestionViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var questionLabel: UILabel!
    
    @IBOutlet weak var answerTable: UITableView!
    
    public var currentQuestion: Question?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.questionLabel.text = currentQuestion?.text
    }
    
    
    // UITableViewDataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return currentQuestion?.answers.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: nil)
        
        let answer = currentQuestion?.answers[indexPath.row]
        
        cell.textLabel?.text = answer?.text
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let myStoryboard = UIStoryboard.init(name: "MyStoryboard", bundle: nil)
        
        let answer = currentQuestion?.answers[indexPath.row]
        
        if (answer?.nextQuestion != nil) {
            let questionVC = myStoryboard.instantiateViewController(withIdentifier: "QuestionVC") as! QuestionViewController
            questionVC.currentQuestion = answer?.nextQuestion
            show(questionVC, sender: nil)
        } else {
            let finalViewController = myStoryboard.instantiateViewController(withIdentifier: "FinalViewController") as! FinalViewController
            finalViewController.finalText = answer?.final
            show(finalViewController, sender: nil)
        }
    }
    
    
    
    
    
}
