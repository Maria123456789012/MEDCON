//
//  MedicinaTests.swift
//  MedicinaTests
//
//  Created by Masha on 27/02/2019.
//  Copyright © 2019 Masha. All rights reserved.
//

import XCTest
@testable import Medicina


class MedicinaTests: XCTestCase {
    
    let networkService = NetworkService()
    
    var json: Any? {
        let bundle = Bundle(for: type(of: self))
        let filePathj = bundle.path(forResource: "test", ofType: "json")
        guard let filePath = filePathj else {
            return nil
        }
        
        let fileUrl = URL(fileURLWithPath: filePath)
        
        let data = try? Data(contentsOf: fileUrl)
        
        let jsonData = try? JSONSerialization.jsonObject(with: data!, options: [.allowFragments])

        return jsonData
    }
    

    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() {
        guard let json = json else {
            XCTFail("no json")
            return
        }
        
        self.networkService.parse(json)
        
    }


}
